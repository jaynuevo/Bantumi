# Bantumi
Alpha Beta Pruning

Buttons palat aadi tas player1 pala haha
